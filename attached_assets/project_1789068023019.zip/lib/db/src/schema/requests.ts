import { pgTable, text, serial, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const specialRequestsTable = pgTable("special_requests", {
  id: serial("id").primaryKey(),
  requesterName: text("requester_name").notNull(),
  requesterEmail: text("requester_email"),
  department: text("department"),
  location: text("location"),
  title: text("title").notNull(),
  details: text("details").notNull(),
  kind: text("kind").notNull().default("special"),
  neededBy: text("needed_by"),
  eventDate: text("event_date"),
  shippedAt: timestamp("shipped_at", { withTimezone: true }),
  status: text("status").notNull().default("open"),
  priority: text("priority").notNull().default("standard"),
  resolutionNotes: text("resolution_notes"),
  requestUpdates: jsonb("request_updates")
    .$type<{ message: string; createdAt: string }[]>()
    .notNull()
    .default([]),
  aedStage: text("aed_stage"),
  trackingNumber: text("tracking_number"),
  placementLocation: text("placement_location"),
  maintenanceContactName: text("maintenance_contact_name"),
  maintenanceContactEmail: text("maintenance_contact_email"),
  endReminder2wSentAt: timestamp("end_reminder_2w_sent_at"),
  endReminder1wSentAt: timestamp("end_reminder_1w_sent_at"),
  aedInfo: jsonb("aed_info").$type<{
    makeModel?: string;
    serialNumber?: string;
    batterySerialNumber?: string;
    batteryInstallDate?: string;
    batteryInstalledOn?: string;
    padsInfo?: string;
    padsExpirationDate?: string;
    backupPadsInfo?: string;
    backupPadsExpirationDate?: string;
    placement?: string;
  }>(),
  orderedItems: jsonb("ordered_items").$type<
    { name: string; received: boolean }[]
  >(),
  shipmentChecklist: jsonb("shipment_checklist").$type<
    Record<string, { checked: boolean; note?: string }>
  >(),
  placementToken: text("placement_token"),
  aedInfoToken: text("aed_info_token"),
  placementSubmittedAt: timestamp("placement_submitted_at", {
    withTimezone: true,
  }),
  placementReminderLastSentAt: timestamp("placement_reminder_last_sent_at", {
    withTimezone: true,
  }),
  completedBy: text("completed_by"),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  lastNotifiedAt: timestamp("last_notified_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertSpecialRequestSchema = createInsertSchema(
  specialRequestsTable,
).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertSpecialRequest = z.infer<typeof insertSpecialRequestSchema>;
export type SpecialRequest = typeof specialRequestsTable.$inferSelect;
