import { pgTable, text, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const supplyItemsTable = pgTable("supply_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  unit: text("unit").notNull(),
  description: text("description").notNull(),
  sku: text("sku"),
});

export const insertSupplyItemSchema = createInsertSchema(
  supplyItemsTable,
).omit({ id: true });
export type InsertSupplyItem = z.infer<typeof insertSupplyItemSchema>;
export type SupplyItem = typeof supplyItemsTable.$inferSelect;
