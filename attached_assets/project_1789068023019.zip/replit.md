# Supply Hub

An internal supply ordering app for AED (defibrillator) supplies and special requests — staff submit order forms and requests, coordinators track everything to delivery.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Frontend: React + Vite (wouter, TanStack Query, shadcn/Tailwind)

## Where things live

- API contract: `lib/api-spec/openapi.yaml` (source of truth)
- DB schema: `lib/db/src/schema/` (supplies, orders + order_items, requests)
- API routes: `artifacts/api-server/src/routes/` (supplies, orders, requests, dashboard)
- Frontend: `artifacts/supply-hub/` (pages: Dashboard, OrderForm, OrdersList, RequestsList)

## Architecture decisions

- Orders store line items in a separate `order_items` table joined to the supply catalog; API responses embed items with supply names.
- Statuses are plain text columns validated at the API layer: orders `submitted|approved|ordered|shipped|delivered|cancelled`; requests `open|in_review|approved|fulfilled|declined`; priority `standard|urgent`.
- The Orval input transformer in `lib/api-spec/orval.config.ts` rewrites `type: integer` → `number` because the workspace pins Zod v3 and Orval emits Zod v4 `zod.int()` for integers. Keep this when editing the config.

## Product

- Dashboard: summary counts, urgent flags, status breakdowns, recent activity feed
- Supply order form: catalog-driven multi-item orders with requester/location/priority
- Order tracking: search/filter, detail dialog, status updates
- Special requests: submission form, review dialog with status + resolution notes

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Reminder emails in production

- Reminder emails (daily for urgent items, weekly for standard) are sent by `runReminderPass` in `artifacts/api-server/src/notifications.ts`. An in-process hourly scheduler runs while the server is up, but the published autoscale deployment can scale to zero with no traffic.
- External cron trigger: `POST /api/internal/cron/reminders` with `Authorization: Bearer $CRON_SECRET` (env var `CRON_SECRET`, shared). Idempotent — `lastNotifiedAt` gates each item, so overlapping triggers won't double-send.
- The published app is private, so an external caller also needs a Replit external access token (Publishing → Adjust settings → Security) passed as a second header or `?project-protection-bypass=` param.

## Gotchas

- Rerun codegen after any `openapi.yaml` change; do not edit generated files.
- Timestamps are serialized to ISO strings in route handlers before Zod response parsing.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
